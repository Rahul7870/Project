# E-Commerce-Grocery-Shop

This is a front-end project for an ecommerce grocery shop website

**Live site -** [https://e-grocery-shop.netlify.app/](https://e-grocery-shop.netlify.app/)

## Preview
![img01](https://user-images.githubusercontent.com/83011210/228043559-4ddc4c2c-cece-4274-b0da-a9daa780bbf0.png)
![inside01](https://user-images.githubusercontent.com/83011210/228046936-8f8bf6c7-5444-4faa-ac6f-d3b94a87725a.png)
![inside02](https://user-images.githubusercontent.com/83011210/228047094-ef607573-a3f7-46bb-a801-cf15fd12010f.png)
![inside03](https://user-images.githubusercontent.com/83011210/228047155-9899560c-83d4-45ed-9fa9-ef56d4e47c06.png)
![img02](https://user-images.githubusercontent.com/83011210/228043701-602e63cb-1389-4aee-9349-04c79c8b49fd.png)
![lst01](https://user-images.githubusercontent.com/83011210/228186345-b4da14dd-da94-48e7-9b04-d238d6225145.png)
![lst02](https://user-images.githubusercontent.com/83011210/228186684-712e2e20-d9b0-44d9-9a8e-36a826da2e74.png)
![lst03](https://user-images.githubusercontent.com/83011210/228186739-5fdb94d4-d800-406d-b5e5-e39ab4cb94b7.png)
![lst04](https://user-images.githubusercontent.com/83011210/228186955-748d06dd-8979-43e7-b5a2-5b780fda39e8.png)
![lst05](https://user-images.githubusercontent.com/83011210/228187007-f0150400-b501-44dd-af97-1e9521578de2.png)
![lst06](https://user-images.githubusercontent.com/83011210/228187058-a96e1926-3d7f-4dc3-8776-bc80e2b89994.png)
![img03](https://user-images.githubusercontent.com/83011210/228043758-455f42bd-1e71-4ec2-b2ec-8d17f4d3d209.png)
![img04](https://user-images.githubusercontent.com/83011210/228044605-1ea5ce48-53a3-44ac-a18a-d1f1a3b8ced2.png)
![img05](https://user-images.githubusercontent.com/83011210/228043821-c8b89c66-05ff-4c40-b485-51758711b9e8.png)
![img06](https://user-images.githubusercontent.com/83011210/228043874-328fce9e-6caf-4d4f-81dd-e346f20b96cd.png)
![category](https://user-images.githubusercontent.com/83011210/228050636-045d3bbb-b57c-47ac-9f1d-8f917b954429.png)
![img07](https://user-images.githubusercontent.com/83011210/228043950-7d076f86-365d-4898-955e-b9542d617738.png)
![img08](https://user-images.githubusercontent.com/83011210/228044020-3a613927-4152-4bc5-ab70-fe43bce10f4c.png)
![img09](https://user-images.githubusercontent.com/83011210/228044276-b5c9533a-2ece-4192-9f2b-2376173fff09.png)
![img009](https://user-images.githubusercontent.com/83011210/228050494-f006debe-3d24-42d5-bf9f-b799b224cd84.png)
![img10](https://user-images.githubusercontent.com/83011210/228044390-85a0367d-0c1f-472c-9e8a-7cd9707d7616.png)
![img11](https://user-images.githubusercontent.com/83011210/228044477-d1cfc0e4-150e-4824-9909-6ce36b124f26.png)
![img12](https://user-images.githubusercontent.com/83011210/228044555-8ed31845-82b0-4b5f-8a0d-f2af2d5a9d44.png)
