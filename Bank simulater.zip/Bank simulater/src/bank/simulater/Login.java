
package bank.simulater;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    JButton login,signup,clear;
     JTextField tf1;
     JPasswordField ps1;
     
    Login()
    { setLayout(null);
    
    ImageIcon backg=new ImageIcon(ClassLoader.getSystemResource("icons/loginIMG.jpg"));
    JLabel bg=new JLabel(backg,JLabel.CENTER);
    bg.setBounds(0,0,1150,600);
    add(bg);
            
    ImageIcon back=new ImageIcon(ClassLoader.getSystemResource("icons/loginIMG.jpg"));
    JLabel bg1=new JLabel(backg,JLabel.CENTER);
    bg1.setBounds(0,0,915,600);
    add(bg1);
   
    
         setTitle("Bank Simulator");
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/logobnk.png"));

         Image i2= i1.getImage().getScaledInstance(50, 70,Image.SCALE_DEFAULT);
         ImageIcon i3=new ImageIcon(i2);
         

    JLabel L1=new JLabel(i3);
    L1.setBounds(100,20,70,70);
    bg.add(L1);
    
    //label
    JLabel t=new JLabel("WELCOME TO PNB ATM");
    t.setBounds(180,30,400,50);
   t.setFont(new Font("Relway",Font.BOLD,30));
   t.setForeground(Color.BLACK);
     bg.add(t);
     
   JLabel t1=new JLabel("CARD NO:");
     t1.setBounds(120,120,200,70);
     t1.setForeground(Color.WHITE);
     t1.setFont(new Font("Relway",Font.BOLD,25 ));
     bg.add(t1);
     
     JLabel t2=new JLabel("PIN NO:");
     t2.setBounds(120,210,200,70);
     t2.setForeground(Color.WHITE);
     t2.setFont(new Font("Relway",Font.BOLD,25));
     bg.add(t2);
     
     //textfield
     
      tf1=new JTextField();
     tf1.setBounds(300,135,190,40);
     tf1.setFont(new Font("Ariel",Font.BOLD,15));
     tf1.setForeground(Color.red);
     bg.add(tf1);
 
      ps1=new JPasswordField();
     ps1.setBounds(300,225,190,40);
     ps1.setFont(new Font("Ariel",Font.BOLD,15));
     ps1.setForeground(Color.red);
     bg.add(ps1);
   //button
   login=new JButton("LOGIN");
   login.setBounds(180,300,90,30);
   bg.add(login);
   login.setBackground(Color.BLACK);
   login.setForeground(Color.WHITE);
   login.addActionListener(this);
   
   clear=new JButton("CLEAR");
  clear.setBounds(320,300,90,30);
   bg.add(clear);
   clear.setBackground(Color.BLACK);
   clear.setForeground(Color.WHITE);
   clear.addActionListener(this);
   
   
   signup= new JButton("SIGNUP");
   signup.setBounds(180,350,230,30);
   bg.add(signup);
   signup.setBackground(Color.BLACK);
   signup.setForeground(Color.WHITE);
   signup.addActionListener(this);
      
   
   getContentPane().setBackground(Color.white);
    setSize(700,480);
    setVisible(true);
    setLocation(300,120);
   
    
    }
    public void actionPerformed(ActionEvent e)
    {
        try{ 
    
        if(e.getSource()== login)
        {
             
               Conn c1 = new Conn();
             String cardno  = tf1.getText();
                String pin  = ps1.getText();
                String q  = "select * from login where cardno = '"+cardno+"' and pin = '"+pin+"'";

                ResultSet rs = c1.s.executeQuery(q);
                if(rs.next()){
                    setVisible(false);
                    new Transactions(pin).setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
                }
           
        }
        else if(e.getSource()== signup)
        {
            setVisible(false);
           Signup ob =new Signup();
           ob.setVisible(true);
        }
        else if(e.getSource()== clear)
        {
            tf1.setText(" ");
            ps1.setText("");
        }
           }
        catch(Exception ae){
             ae.printStackTrace();
                }
    }
    
    public static void main (String[] args)
    {
        new Login();
    
    }    
    
    
}
