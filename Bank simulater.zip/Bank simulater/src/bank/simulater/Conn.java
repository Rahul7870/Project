
package bank.simulater;
import java.sql.*;
public class Conn {
    Connection c;
    Statement s;
    public Conn()
    {
    try
    {
        c=DriverManager.getConnection("jdbc:mysql:///BankSimulater","root","Rahul@#12345");
        s=c.createStatement();
    
    }
    catch(Exception e)
    {
    System.out.println(e);
    }
    }
    
}
