
package bank.simulater;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class Signup extends JFrame implements ActionListener{
    JLabel formno,pd;
    JLabel nameL,fnameL,dobL,genderL,emailL,maritalL,addressL,cityL,stateL,pinL;
    JTextField nameT,fnameT,emailT,addressT,cityT,stateT,pinT;
    JRadioButton male,female,unmarried,married;
    JButton next;
    JDateChooser dob;
       Random ran;
       long frandom;
       JColorChooser ch;
    Signup()
    { setLayout(null);
       ran =new Random();
        frandom=(Math.abs(ran.nextLong()%9000L)+1000L);
        
        
         ImageIcon backg=new ImageIcon(ClassLoader.getSystemResource("icons/Signup.jpg"));
    JLabel bg=new JLabel("",backg,JLabel.CENTER);
    bg.setBounds(0,0,900,950);
    add(bg);
   
  ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logobnk.png"));
        Image i2 = i1.getImage().getScaledInstance(60, 75, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l14 = new JLabel(i3);
        l14.setBounds(66, 10, 70, 70);
        bg.add(l14);
    
     //labels
        formno=new JLabel("APPLICATION FORM NO. "+frandom);
        formno.setBounds(150,10,500,50);
         formno.setForeground(Color.WHITE);
        formno.setFont(new Font("Relway",Font.BOLD,30));
        bg.add(formno);
        
        pd=new JLabel("Page-1: Personal Details"); 
        pd.setBounds(250,50,400,30);
        pd.setFont(new Font("Relway",Font.BOLD,22));
        bg.add(pd);
         pd.setForeground(Color.WHITE);
         
        nameL =new JLabel("Name:");
        nameL.setBounds(150,120,150,20);
        nameL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(nameL);
         nameL.setForeground(Color.WHITE);
        
        fnameL=new JLabel("Father's Name:");
        fnameL.setBounds(150,160,150,20);
        fnameL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(fnameL);
         fnameL.setForeground(Color.WHITE);
        
        dobL=new JLabel("Date Of Birth:");
        dobL.setBounds(150,200,150,20);
        dobL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(dobL);
         dobL.setForeground(Color.WHITE);
        
        genderL=new JLabel("Gender:");
        genderL.setBounds(150,240,150,20);
        genderL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(genderL);
         genderL.setForeground(Color.WHITE);
       
        emailL=new JLabel("Email:");
        emailL.setBounds(150,280,150,20);
        emailL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(emailL);
        emailL.setForeground(Color.WHITE);
        
         maritalL=new JLabel("Marital Status:");
        maritalL.setBounds(150,320,150,20);
        maritalL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(maritalL);
        maritalL.setForeground(Color.WHITE);
         
         addressL=new JLabel("Address:");
        addressL.setBounds(150,360,150,20);
        addressL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(addressL);
        addressL.setForeground(Color.WHITE);
        
         cityL =new JLabel("City");
         cityL.setBounds(150,400,150,20);
         cityL.setFont(new Font("Relway",Font.BOLD,18));
         bg.add(cityL) ;
         cityL.setForeground(Color.WHITE);
         
          
         stateL=new JLabel("State:");
        stateL.setBounds(150,440,150,20);
        stateL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(stateL);
        stateL.setForeground(Color.WHITE);
        
         pinL=new JLabel("Pin Code:");
        pinL.setBounds(150,480,150,20);
        pinL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(pinL);
        pinL.setForeground(Color.WHITE);
        
        //textfields
        
       nameT=new JTextField("Enter yor Name");
       nameT.setBounds(320,120,280,20);
       bg.add(nameT);
       
      fnameT=new JTextField();
       fnameT.setBounds(320,160,280,20);
       bg.add(fnameT);
       
       dob =new JDateChooser();
      dob.setBounds(320,200,280,20);
      bg.add(dob);
      
        male=new JRadioButton("Male");
       male.setBounds(320,240,80,20);
       bg.add(male);
        male.setBackground(Color.WHITE);
       female =new JRadioButton("Female");
       female.setBounds(410,240,80,20);
       bg.add(female);
       female.setBackground(Color.WHITE);
       
       ButtonGroup bg1=new ButtonGroup();
       bg1.add(male);
         bg1.add(female);
     
       
         emailT=new JTextField();
       emailT.setBounds(320,280,280,20);
      bg. add(emailT);
       
         married=new JRadioButton("Married");
       married.setBounds(320,320,80,20);
       bg.add(married);
       married.setBackground(Color.WHITE);
       
      unmarried =new JRadioButton("Unmarried");
       unmarried.setBounds(410,320,100,20);
       bg.add(unmarried);
       unmarried.setBackground(Color.WHITE);
       
       ButtonGroup bg2=new ButtonGroup();
       bg2.add(married);
       bg2.add(unmarried);
       
         addressT=new JTextField();
       addressT.setBounds(320,360,280,20);
       bg.add(addressT);
       
       cityT =new JTextField();
       cityT.setBounds(320,400,280,20);
       bg.add(cityT);
       
       stateT=new JTextField();
       stateT.setBounds(320,440,280,20);
       bg.add(stateT);
        
       pinT=new JTextField();
       pinT.setBounds(320,480,280,20);
       bg.add(pinT);
       
       
       //button
       
       next=new JButton("NEXT");
       next.setBounds(520,530,80,30);
       next.setBackground(Color.BLACK);
         next.setForeground(Color.WHITE);
         next.addActionListener(this);
       bg.add(next);
     
        
        
        
    setSize(800,840);
    setVisible(true);
    setLocation(250,5);
    getContentPane().setBackground(Color.WHITE);
        
    
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String formno=""+ frandom;
        String name=nameT.getText();
        String fname= fnameT.getText();
        String DOB=((JTextField) dob.getDateEditor().getUiComponent()).getText();
        String gender=null;
        if(male.isSelected())
        {
            gender="Male";
        }
        else if(female.isSelected())
        {
            gender="Female";
        }
        String email=emailT.getText();
        String marital=null;
        if(married.isSelected())
        {
        marital="Married";
        }
        else if(unmarried.isSelected())
        {
        marital="Unmarried";
        }
        String address=addressT.getText();
        String city=cityT.getText();
        String state = stateT.getText();
        String pin =pinT.getText();
        
       
        //constraints
        
        if(name.equals(""))
        JOptionPane.showMessageDialog(null,"Name is Required"); 
      
        else if(fname.equals(""))
         JOptionPane.showMessageDialog(null,"Father's Name is Required");
        
        else if(DOB.equals(""))
            JOptionPane.showMessageDialog(null, "DOB is Required");
        
        else if(gender.equals(""))
            JOptionPane.showMessageDialog(null,"Gender is Required");
        
        else if(email.equals(""))
        JOptionPane.showMessageDialog(null,"Email is Required");
       
        else if(marital.equals(""))
        JOptionPane.showMessageDialog(null,"Marital is Required");
        
        else if(address.equals(""))
        JOptionPane.showMessageDialog(null,"Address is Required");
         
        else if(city.equals(""))
        JOptionPane.showMessageDialog(null,"City is Required");
        
        else if(state.equals(""))
            JOptionPane.showMessageDialog(null,"State is Required");
        
         else if(pin.equals(""))
            JOptionPane.showMessageDialog(null,"Pin is Required");
         
         else{
                 
        try{
                   Conn c=new Conn();
            String query="insert into signup1 values('"+formno+"','"+name+"','"+fname+"','"+DOB+"',"
            + "'"+gender+"','"+email+"','"+marital+"','"+address+"','"+city+"','"+state+"','"+pin+"')";
            c.s.executeUpdate(query);
        
        
        }
        catch(Exception ae)
        {
            System.out.print(ae);
        }
        
         setVisible(false);
        Signup2 ob=new Signup2(formno);
        ob.setVisible(true);
    }
    }
    
    public static void main(String[] args)
    {
       new Signup(); 
    }
    
    
}
